import boto3
import pprint
import os

Build="10.0312"
region = "us-east-1"
ecs = boto3.client('ecs')

def lambda_handler(event, context):
    taskdefinition_response_rms = ecs.register_task_definition(
        family='rms-testdrm-com',
        containerDefinitions=[
            {
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                "awslogs-group": "/ecs/rms-testdrm-com",
                "awslogs-region": "us-east-1",
                "awslogs-stream-prefix": "ecs"
                }
                },
            "portMappings": [
                {
                "hostPort": 0,
                "protocol": "tcp",
                "containerPort": 8443
                }
            ],
            "mountPoints": [
                {
                "containerPath": "/var/opt/nextlabs/rms/shared/",
                "sourceVolume": "rms-shared"
                }
            ],
            "memoryReservation": 500,
            "image": "579292207088.dkr.ecr.us-east-1.amazonaws.com/skydrm/skydrm-rms:"+Build,
            "name": "rms"
            }
        ],
        requiresCompatibilities= [
            "EC2"
        ],
        networkMode= "bridge",
        volumes= [
            {
            "name": "rms-shared",
            "host": {
                "sourcePath": "/mnt/efs/testdrm-com/shared"
            }
            }
    ]
    )

    taskdefinition_response_router = ecs.register_task_definition(
        family='router-testdrm-com',
        containerDefinitions=[
        {
        "logConfiguration": {
            "logDriver": "awslogs",
            "options": {
            "awslogs-group": "/ecs/router-testdrm-com",
            "awslogs-region": "us-east-1",
            "awslogs-stream-prefix": "ecs"
            }
            },
        "portMappings": [
            {
            "hostPort": 0,
            "protocol": "tcp",
            "containerPort": 8443
            }
        ],
        "mountPoints": [
            {
            "containerPath": "/var/opt/nextlabs/rms/shared/",
            "sourceVolume": "router"
            }
        ],
        "memoryReservation": 500,
        "image": "579292207088.dkr.ecr.us-east-1.amazonaws.com/skydrm/skydrm-router:"+Build,
        "essential": True,
        "name": "router"
        }
    ],
    requiresCompatibilities=[
        "EC2"
    ],
    networkMode="bridge",
    volumes=[
        {
        "name": "router",
        "host": {
            "sourcePath": "/mnt/efs/testdrm-com/shared"
        }
        }
    ]
    )

    taskdefinition_response_viewer = ecs.register_task_definition(
        family='viewer-testdrm-com',
        containerDefinitions=[
        {
        "logConfiguration": {
            "logDriver": "awslogs",
            "options": {
            "awslogs-group": "/ecs/viewer-testdrm-com",
            "awslogs-region": "us-east-1",
            "awslogs-stream-prefix": "ecs"
            }
            },
        "portMappings": [
            {
            "hostPort": 0,
            "protocol": "tcp",
            "containerPort": 8443
            }
        ],
        "mountPoints": [
            {
            "containerPath": "/var/opt/nextlabs/rms/shared/",
            "sourceVolume": "rms-shared"
            },
            {
            "containerPath": "/opt/nextlabs/rms/viewer/viewers/",
            "sourceVolume": "viewer-packages"
            }
        ],
        "memoryReservation": 500,
        "image": "579292207088.dkr.ecr.us-east-1.amazonaws.com/skydrm/skydrm-viewer:"+Build,
        "essential": True,
        "name": "viewer"
        }
    ],
    requiresCompatibilities=[
        "EC2"
    ],
    networkMode="bridge",
    volumes=[
        {
        "name": "rms-shared",
        "host": {
            "sourcePath": "/mnt/efs/testdrm-com/shared"
        }
        },
        {
        "name": "viewer-packages",
        "host": {
            "sourcePath": "/mnt/efs/testdrm-com/shared/viewerPackages"
        }
        }
    ]
    )
    #print taskDefinition revision
    pprint.pprint(taskdefinition_response_rms['taskDefinition']['revision'])
    pprint.pprint(taskdefinition_response_router['taskDefinition']['revision'])
    pprint.pprint(taskdefinition_response_viewer['taskDefinition']['revision'])
    #Update service
    taskDefinitionRev_rms = taskdefinition_response_rms['taskDefinition']['family'] + ':' + str(taskdefinition_response_rms['taskDefinition']['revision'])
    taskDefinitionRev_router= taskdefinition_response_router['taskDefinition']['family'] + ':' + str(taskdefinition_response_router['taskDefinition']['revision'])
    taskDefinitionRev_viewer = taskdefinition_response_viewer['taskDefinition']['family'] + ':' + str(taskdefinition_response_viewer['taskDefinition']['revision'])
    
    service_response_rms = ecs.update_service(
        cluster='TESTDRM-COM',
        service='rms-testdrm-com',
        desiredCount=1,
        forceNewDeployment=True,
        taskDefinition=taskDefinitionRev_rms,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    service_response_router = ecs.update_service(
        cluster='TESTDRM-COM',
        service='router-testdrm-com',
        desiredCount=1,
        forceNewDeployment=True,
        taskDefinition=taskDefinitionRev_router,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    service_response_viewer = ecs.update_service(
        cluster='TESTDRM-COM',
        service='viewer-testdrm-com',
        desiredCount=1,
        forceNewDeployment=True,
        taskDefinition=taskDefinitionRev_viewer,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    #print "service updated"
    pprint.pprint(service_response_rms)
    pprint.pprint(service_response_router)
    pprint.pprint(service_response_viewer)
   

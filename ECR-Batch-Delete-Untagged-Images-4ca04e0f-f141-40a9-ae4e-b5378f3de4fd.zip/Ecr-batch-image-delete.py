import boto3
from botocore.exceptions import ClientError
#Create ECR instance with Boto3
ecr = boto3.client('ecr')
allrepository = ecr.describe_repositories()
def lambda_handler(event, context):
    for repository in allrepository['repositories']:
        try:
            #Get all untagged images
            response = ecr.list_images(
            repositoryName=repository['repositoryName'],
            filter={
                'tagStatus': 'UNTAGGED'
            }
            )
            if response['imageIds']!=[]:
                print(repository['repositoryName'])
                print(response['imageIds'])
                #Batch delete all untagged images
                response = ecr.batch_delete_image(
                repositoryName=repository['repositoryName'],
                imageIds=response['imageIds']
                )
        except ClientError as e:
            print('Error',e)
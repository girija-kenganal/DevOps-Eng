import boto3
from datetime import datetime
from botocore.exceptions import ClientError

ec2 = boto3.resource('ec2')
def lambda_handler(event, context):
    print(event)     
    eventname = event['detail']['eventName']
    principal = event['detail']['userIdentity']['principalId']
    userType = event['detail']['userIdentity']['type']
    region = event['region']
    time = event['time']
    print(time)
    print(region)
    print(eventname)
    print(principal)
    print(userType)
    
    awsAccounts=['579292207088']
    
    for accountNumber in awsAccounts:
        try:
      
            ec2_client = boto3.client('ec2')
              
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            print(regions)
            
            for region in regions:
                if userType == 'IAMUser':
                    user = event['detail']['userIdentity']['userName']
                    print(user)
            
                else:
                    user = principal.split(':')[1]
                    print('instance is created by principal') 
                    
                if eventname == 'RunInstances':
                    items = event['detail']['responseElements']['instancesSet']['items']
                    ids = []
                    for item in items:
                        ids.append(item['instanceId'])
                        
                        base = ec2.instances.filter(InstanceIds=ids)
                        print(base)
                        print(ids)
            
                        if ids:
                            ec2.create_tags(
                                Resources=ids, 
                                Tags=[
                                    {
                                        'Key': 'Owner', 
                                        'Value': user
                                    },    
                                    {
                                        'Key': 'Region',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'Project',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'TTL Start Time',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'TTL Shutdown Time',
                                        'Value': '19'
                                        
                                    },
                                    {
                                        'Key': 'Day',
                                        'Value': ''
                                    
                                    },
                                    {
                                        'Key': 'Archive',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'Name',
                                        'Value': 'New Instance'
                                        
                                    },
                                    {
                                        'Key': 'Project Start Date',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'Project End Date',
                                        'Value': ''
                                        
                                    },
                                    {
                                        'Key': 'Purpose',
                                        'Value': ''
                                        
                                    }
                                ]
                            )
                            print('All tags are created successfully for new instance')
                            
        except ClientError as e:
            print(e)                                  
                                        
    return "success"                        

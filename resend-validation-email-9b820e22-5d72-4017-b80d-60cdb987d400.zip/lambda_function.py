import json,boto3
from botocore.vendored import requests
import hashlib,hmac,random
import pprint
import os

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from boto3.dynamodb.conditions import Key, Attr

from botocore.exceptions import ClientError

dynamodb_table= os.environ["dynamodb_table"]

def lambda_handler(event, context):
    ddbClient = boto3.resource('dynamodb', region_name='us-west-2')
    table = ddbClient.Table(dynamodb_table)
    #print(event)
    email=event['queryStringParameters']['email']
    print(email)


    try:
        
        responseGet = table.scan(FilterExpression=Attr('email').eq(email))
        items = responseGet['Items']
        
        for item in items:
            if item['email']==email:
                firstName=item['firstName']
                fromEmail =  "admin@cloudaz.com"
                toEmail = email

                # Create message container - the correct MIME type is multipart/alternative.
                msg = MIMEMultipart('alternative')
                msg['Subject'] = "CloudAz-: NextLabs CloudAz service - Verify your account"
                msg['From'] = fromEmail
                msg['To'] = toEmail
                
                # Create the body of the message (a plain-text and an HTML version).
               
                html = """
                    <html>
                      <style type="text/css">
                        body {
                          font-family: "Lato", "Lucida Grande", "Lucida Sans Unicode", Tahoma, Sans-Serif;
                        }
                        .divButton {
                          background-color:#FF6101;
                          color:white;
                          padding:10px;
                          width:300px;
                        }
                      </style>
        
                    <body>
                    """
                html=html + 'Hello ' + firstName
        
                html=html + """
                  <p>
                    Thank you for signing up for a trial account with the Nextlabs’s CloudAz. 
                    We're excited to introduce you to Attribute Based Access Control and Dynamic Authorization in the cloud.
                  </p>
        
                  <p>
                  Please help us understand your unique business situation by answering the following questions and replying to this email: 
                  </p>
        
                  <ol>
                    <li>What type of applications are you planning to integrate with this service?  </li>
                    <li>What programming languages are these applications written in? </li>
                    <li>Anything else we should know or can help you to make the trial successful? </li>
                  </ol>
        
                  <p>Once we receive your response, we will activate your trial account and send you a confirmation email  with login information. </p>
                  <p>Meanwhile, if you have any questions, please reply to this email or call <a href="tel:18008983065">1-800-898-3065</a>. </p>
        
                  <p>Welcome to NextLabs!</p>
                  Thank you,<br>
                  NextLabs, Inc.
                    </body>
                  </html>
                """
                
                part2 = MIMEText(html, 'html')
                try:
                    msg.attach(part2)
                    server = smtplib.SMTP('smtp.gmail.com', 587)
                    server.starttls()
                    server.login("admin@cloudaz.com", "sgjunjhxnqisfmwr")
                    server.sendmail(fromEmail, toEmail, msg.as_string())
                    server.quit()
                    print("email has been re-sent successfully")
                    # Now update dynamodb table with customerNotified='y' for the customerEmaill
                    try:
                        responseDdb = table.update_item(
                                            Key={
                                                'email': email
                                                
                                            },
                                            UpdateExpression='SET numResend = numResend + :val1',
                                            ExpressionAttributeValues={
                                                ':val1': 1
                                            }
                                        )
                        print("numResend updated successfully")
                        
                    except ClientError as e:
                        print(e)
                        return { 
                                "statusCode": 500,
                                "body": json.dumps("error"),
                                "isBase64Encoded": "false",
                                 "headers": {
                                        "Access-Control-Allow-Origin" : "*", 
                                        "Access-Control-Allow-Credentials" : "true"
                                 }
                            
                        }
       
                   
                
                except smtplib.SMTPException as e:
                    print(str(e))
                    return { 
                            "statusCode": 500,
                            "body": json.dumps("error"),
                            "isBase64Encoded": "false",
                            "headers": {
                                    "Access-Control-Allow-Origin" : "*", 
                                    "Access-Control-Allow-Credentials" : "true"
                             }
                    
                    }

        
    
    except ClientError as e:
        print(set(e))
        return { 
                "statusCode": 500,
                "body": json.dumps("error"),
                "isBase64Encoded": "false",
                "headers": {
                        "Access-Control-Allow-Origin" : "*", 
                        "Access-Control-Allow-Credentials" : "true"
                 }
            
        }

       

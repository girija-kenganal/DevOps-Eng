import boto3
import pprint
import os

Build="10.0268"
region = "us-west-2"
ecs = boto3.client('ecs')
def lambda_handler(event, context):
    taskdefinition_response_rms = ecs.register_task_definition(
        family='rms-testdrm-com',
        containerDefinitions=[
            {
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                "awslogs-group": "/ecs/rms-testdrm-com",
                "awslogs-region": "us-east-1",
                "awslogs-stream-prefix": "ecs"
                }
                },
            "portMappings": [
                {
                "hostPort": 0,
                "protocol": "tcp",
                "containerPort": 8443
                }
            ],
            "mountPoints": [
                {
                "containerPath": "/var/opt/nextlabs/rms/shared/",
                "sourceVolume": "rms-shared"
                }
            ],
            "memoryReservation": 500,
            "image": "579292207088.dkr.ecr.us-east-1.amazonaws.com/skydrm-rms:"+Build,
            "name": "rms"
            }
        ],
        requiresCompatibilities= [
            "EC2"
        ],
        networkMode= "bridge",
        volumes= [
            {
            "name": "rms-shared",
            "host": {
                "sourcePath": "/mnt/efs/testdrm-com/shared"
            }
            }
    ]
    )
    # response1 = ecs.list_task_definitions(
    #     familyPrefix='rms-testdrm-com',  
    #     status='ACTIVE',
    #     sort='DESC'
    #     )
    # print(response1['taskDefinitionArns'][0])
    #taskDefinitionRev = response1['taskDefinitionArns'][0]
    pprint.pprint(taskdefinition_response_rms['taskDefinition']['revision'])
    #Update service
    taskDefinitionRev = taskdefinition_response_rms['taskDefinition']['family'] + ':' + str(taskdefinition_response_rms['taskDefinition']['revision'])
    service_response = ecs.update_service(
        cluster='devops-testdrm-com',
        service='rms-testdrm-com',
        desiredCount=1,
        taskDefinition=taskDefinitionRev,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    pprint.pprint(service_response)
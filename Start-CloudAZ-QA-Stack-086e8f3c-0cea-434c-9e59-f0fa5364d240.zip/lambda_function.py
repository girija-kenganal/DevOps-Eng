import json
import boto3
import time
from botocore.exceptions import ClientError

from urllib.error import URLError, HTTPError

ECS_CLUSTER_NAME='QA-CLOUDAZ-NET'

def lambda_handler(event, context):
    
    # get rds client object
    rds = boto3.client('rds', region_name='us-west-2')
    dbs = rds.describe_db_instances()
    
    for db in dbs['DBInstances']:
        print(db['DBInstanceIdentifier'])
        print(db['DBInstanceStatus'])
        
        if (db['DBInstanceIdentifier'] == 'cloudaz-dev-qa-upgrade' and db['DBInstanceStatus'] == 'stopped'):
            start_rds = rds.start_db_instance(
                DBInstanceIdentifier='cloudaz-dev-qa-upgrade'
            )
            print("Waiting for RDS to become available");
        
            time.sleep(60);      
    
        if db['DBInstanceStatus'] == 'available':
            try:
                # get autoscaling client object
                asg = boto3.client('autoscaling', region_name='us-west-2')
                # scaled-up ASG with existing LC
                asg_scaleup = asg.update_auto_scaling_group(
                      AutoScalingGroupName = 'CC-QA-CLOUDAZ-NET-ASG',
                      LaunchConfigurationName = 'QA-CLOUDAZ-NET-LC',
                      MaxSize=3,
                      MinSize=1,
                      DesiredCapacity=3,
                      DefaultCooldown=300,
                      HealthCheckType='EC2',
                      HealthCheckGracePeriod=300,
                      AvailabilityZones=[
                         'us-west-2a',
                         'us-west-2b'
                      ]
                )
                print("Updated autoscaling with 2 instances")
                time.sleep(100);
                # get ecs client object
                ecs = boto3.client('ecs', region_name='us-west-2')
                
                containerInstance = ecs.list_container_instances(
                    cluster=ECS_CLUSTER_NAME,
                    status='ACTIVE',
                )
                print(containerInstance)
                
                containerInstanceArns = containerInstance['containerInstanceArns']
                print(containerInstanceArns)
                
                # to get contsiner instance ARN
                containerInstanceDetails = ecs.describe_container_instances(
                    cluster=ECS_CLUSTER_NAME,
                    containerInstances=containerInstanceArns
                )
                #print(containerInstanceDetails)
                ContainerInstanceArn = containerInstanceDetails["containerInstances"][0]['containerInstanceArn']
                #Ec2InstanceId = containerInstanceDetails["containerInstances"][0]['ec2InstanceId']
                print(ContainerInstanceArn)
                #print(Ec2InstanceId)
                
                
                print("Waiting for EC2 instances to register with ECS cluster");
                
                time.sleep(200);
                
                print("Starting CC container");
                
                update_service_cc = ecs.update_service(
                    cluster=ECS_CLUSTER_NAME,
                    service='cc',
                    desiredCount=1,
                    forceNewDeployment=False,
                    taskDefinition='cc-qa:10',
                    deploymentConfiguration={
                        'maximumPercent': 200,
                        'minimumHealthyPercent': 100
                    }
                )

                time.sleep(200);
                
                print("Starting NGINX container");
                
                update_service_pv = ecs.update_service(
                    cluster=ECS_CLUSTER_NAME,
                    service='nginx',
                    desiredCount=1,
                    forceNewDeployment=False,
                    taskDefinition='nginx-qa:14',
                    deploymentConfiguration={
                        'maximumPercent': 200,
                        'minimumHealthyPercent': 100
                    }
                )
                
                time.sleep(200);
                print("Starting ICENET container");
                
                update_service_pv = ecs.update_service(
                    cluster=ECS_CLUSTER_NAME,
                    service='icenet',
                    desiredCount=1,
                    forceNewDeployment=False,
                    taskDefinition='icenet-qa:6',
                    deploymentConfiguration={
                        'maximumPercent': 200,
                        'minimumHealthyPercent': 100
                    }
                )
                
                time.sleep(120);
                print("Starting JPC container");
                
                update_service_jpc = ecs.update_service(
                    cluster=ECS_CLUSTER_NAME,
                    service='jpc',
                    desiredCount=1,
                    forceNewDeployment=False,
                    taskDefinition='jpc-qa:7',
                    deploymentConfiguration={
                        'maximumPercent': 200,
                        'minimumHealthyPercent': 100
                    }
                )
                
                time.sleep(20);
                print("Starting PV container");
                
                update_service_pv = ecs.update_service(
                    cluster=ECS_CLUSTER_NAME,
                    service='pv',
                    desiredCount=1,
                    forceNewDeployment=False,
                    taskDefinition='pv-qa:8',
                    deploymentConfiguration={
                        'maximumPercent': 200,
                        'minimumHealthyPercent': 100
                    }
                )
            except ClientError as e:
                print(e)   

    

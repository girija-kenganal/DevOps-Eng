import boto3
#import datetime
from datetime import datetime, timedelta, timezone
from botocore.exceptions import ClientError

ec2 = boto3.client('ec2',region_name='us-east-1')


def lambda_handler(event, context):
    snapshots = ec2.describe_snapshots(OwnerIds=['self'])
    print(snapshots)
    for snapshot in snapshots['Snapshots']:
        a = snapshot['StartTime']
        print(a)
        b = a.date()
        c = datetime.now().date()
        print(c)
        d = c - b
        print(d)
        try:
            if  d.days > 1:
                id = snapshot['SnapshotId']
                #id = 'snap-0730f830327ae7a43'
                print(id)
                ec2.delete_snapshot(SnapshotId=id)
        except ClientError as e:
            if 'InvalidSnapshot.InUse' in e.response:
                print("skipping this snapshot")
                continue


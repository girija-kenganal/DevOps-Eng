import boto3

ec = boto3.client('ec2')

def lambda_handler(event, context):
    reservations = ec.describe_instances(
        Filters=[
            {'Name': 'tag-key', 'Values': ['backup', 'Backup']},
        ]
    ).get(
        'Reservations', []
    )
    print(event)
    instances = sum(
        [
            [i for i in r['Instances']]
            for r in reservations
        ], [])
     
    print ("Found %s instances that need backing up" % len(instances))
    for instance in instances:
        for dev in instance['BlockDeviceMappings']:
            if dev.get('Ebs', None) is None:
                continue
            vol_id = dev['Ebs']['VolumeId']
            print ("Found EBS volume %s on instance %s" % (vol_id, instance['InstanceId']))
            #if (vol_id == 'vol-066935f95507570d1'):    
            snap=ec.create_snapshot(
                VolumeId=vol_id,
                #VolumeId='vol-066935f95507570d1',
            )
            snapshot_name = 'N/A'
            if 'Tags' in instance:
                for tags in instance['Tags']:
                    if tags["Key"] == 'Name':
                        snapshot_name = tags["Value"]

            print ("Tagging snapshot with Name: %s" % (snapshot_name))

            ec.create_tags(
                Resources=[
                    snap['SnapshotId'],
                ],
                Tags=[
                    {'Key': 'Name', 'Value': snapshot_name},
                    {'Key': 'Description', 'Value': 'Created by lambda automated backups'}
                ]
            )
import logging
import os
import json,boto3,sys ,datetime ,time
import hashlib,hmac,random
import pprint
import smtplib
import re

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError


#HOOK_URL = os.environ['https://outlook.office.com/webhook/fad8578e-3db4-4fd6-be9f-c480009dc0bd@9677f667-24d2-4a58-a8e2-941644600b04/IncomingWebhook/e2380fa7f1c74778a0d237b91f1ab563/b36e6ea6-7fbf-48b6-a5fa-c60375fecaa6']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    ccUserName="hhh"
    email="xyz@net.com"
    whatApp= "Web"
    whatLanguage= "java"
    anythingElse= "nothing"
    message = {
      "@context": "https://schema.org/extensions",
      "@type": "MessageCard",
      "themeColor": "64a837",
      "title": "**Cloudaz.com new user sign up**",
      "text": "**Request has been approved and user has been notified via email** \n\r User Name =" +ccUserName+ "\n\r Email = " +email+ "\n\r **Questions with Answers** \n\r whatApp =" +whatApp+ "\n\r whatLanguage ="+whatLanguage+ "\n\r anythingElse ="+anythingElse
    }

    req = Request('https://outlook.office.com/webhook/fad8578e-3db4-4fd6-be9f-c480009dc0bd@9677f667-24d2-4a58-a8e2-941644600b04/IncomingWebhook/e2380fa7f1c74778a0d237b91f1ab563/b36e6ea6-7fbf-48b6-a5fa-c60375fecaa6', json.dumps(message).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
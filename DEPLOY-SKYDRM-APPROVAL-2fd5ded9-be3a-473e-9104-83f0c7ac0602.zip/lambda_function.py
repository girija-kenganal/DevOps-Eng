import json
import boto3
import pprint
import time
import requests
import logging
import os
import json,boto3,sys ,datetime ,time
import hashlib,hmac,random
import smtplib
import re

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    # get autoscaling client
    client = boto3.client('autoscaling')
    
    # scaled-up ASG with new instance 
    asg_scaleup_response = client.update_auto_scaling_group(
          AutoScalingGroupName = 'ASG-SKYDRM-APPROVAL',
          LaunchConfigurationName = 'SKYDRM-APPROVAL-LC',
          MaxSize=2,
          MinSize=2,
          DesiredCapacity=2,
          DefaultCooldown=300,
          HealthCheckType='EC2',
          HealthCheckGracePeriod=300,
          AvailabilityZones=[
             'us-east-1a',
             'us-east-1b'
          ],
    )
    # suspend execution for 100 seconds using sleep() method 
    time.sleep( 100 )
    asg_response = client.describe_auto_scaling_groups(
          AutoScalingGroupNames=[
            'ASG-SKYDRM-APPROVAL',
          ],
    )['AutoScalingGroups'][0]
    pprint.pprint(asg_response)
    #pprint.pprint(asg_response['Instances'][1]['HealthStatus'])
    pprint.pprint(asg_response['Instances'][1]['LifecycleState'])
    
    
    # scaled down ASG old instance if new instance is InService
    if asg_response['Instances'][1]['LifecycleState'] == 'InService':
       asg_scaledown_response = client.update_auto_scaling_group(
          AutoScalingGroupName = 'ASG-SKYDRM-APPROVAL',
          LaunchConfigurationName = 'SKYDRM-APPROVAL-LC',
          MaxSize=1,
          MinSize=1,
          DesiredCapacity=1,
          DefaultCooldown=300,
          HealthCheckType='EC2',
          HealthCheckGracePeriod=300,
          AvailabilityZones=[
             'us-east-1a',
             'us-east-1b'
          ],
      )
    else:
      print("New instance of ASG is unhealthy ")
    time.sleep( 60 )  
    try:
        url='https://approval.testdrm.com/index.html'
        response = requests.get(url)
        # If the response was successful, no Exception will be raised
        response.raise_for_status()
    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')  # Python 3.6
    except Exception as err:
        print(f'Other error occurred: {err}')  # Python 3.6
        postFailedMessageToTeams()
    else:
        print('Deployment is successfull')
        postSuccessMessageToTeams()   
def postSuccessMessageToTeams():
    message = {
    "@context": "https://schema.org/extensions",
    "@type": "MessageCard",
    "themeColor": "64a837",
    "title": "Staging Skydrm approval deployment",
    "text": "**Successfully updated to new version**" 
    }

    req = Request('https://outlook.office.com/webhook/a5d1a57b-8685-45a1-b69b-2fedc6a6c633@9677f667-24d2-4a58-a8e2-941644600b04/IncomingWebhook/932e1d1e5e3c45dea6d2536111bb08e2/b36e6ea6-7fbf-48b6-a5fa-c60375fecaa6', json.dumps(message).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)

def postFailedMessageToTeams():
    message = {
    "@context": "https://schema.org/extensions",
    "@type": "MessageCard",
    "themeColor": "64a837",
    "title": "Staging Skydrm approval deployment",
    "text": "**Deployment is failed, please check**" 
    }

    req = Request('https://outlook.office.com/webhook/a5d1a57b-8685-45a1-b69b-2fedc6a6c633@9677f667-24d2-4a58-a8e2-941644600b04/IncomingWebhook/932e1d1e5e3c45dea6d2536111bb08e2/b36e6ea6-7fbf-48b6-a5fa-c60375fecaa6', json.dumps(message).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason) 
    
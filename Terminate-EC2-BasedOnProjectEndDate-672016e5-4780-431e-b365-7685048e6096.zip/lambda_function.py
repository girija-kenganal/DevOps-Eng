import boto3
from datetime import datetime
from pytz import timezone
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
        
   
    awsAccounts=['579292207088']
    
    for accountNumber in awsAccounts:
        try:
      
            ec2_client = boto3.client('ec2')
              
            
            
            #regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            regions = ['us-east-1']
            print(regions)
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2', region_name=region)
            
                snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']},{'Name': 'instance-state-name', 'Values': ['stopped']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                
                    
                
                    if instance_tags:
                
                        for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                
                        try:
                            #print(tagDict[tag['Region']])
                            # dir(instance)
                                
                            if 'sgdc' in tagDict.values():
                                tzone = timezone('Asia/Singapore')
                                sa_time = datetime.now(tzone)
                                print(sa_time)
                                #currTime = int(sa_time.strftime('%H'))
                                
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                print(currDate)
                                #print(tagDict.get('Name'))
                                #print(datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date())
                                if if tagDict.get('Project Start Date') and tagDict.get('Project Start Date') != 'none' and datetime.strptime(tagDict.get('Project Start Date'), '%Y-%m-%d').date() >= currDate:
                                    clientEC2.instances.filter(InstanceIds=[instance.id]).start()
                                    print("Starting EC2 instance -  %s" % str(instance.id))
                                
                                if Archive == 'Disabled': 
                                if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() <= currDate:
                                    clientEC2.instances.filter(InstanceIds=[instance.id]).terminate()
                                    print("Terminating EC2 instance -  %s" % str(instance.id))
                                    msgString=msgString+"Terminating EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                else:
                                    print("Instance tag Archive value is enabled")
                        except ClientError as e:
                            print(e)
                            
                            
        except ClientError as e:
            print(e)
            
    return "success"             

import json,boto3
from botocore.vendored import requests
import pprint
from base64 import urlsafe_b64encode, urlsafe_b64decode
from boto3.dynamodb.conditions import Key, Attr
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from botocore.exceptions import ClientError

dynamodb_table= os.environ["dynamodb_table"]

def lambda_handler(event, context):
    # TODO implement
    print(event)
    ddbClient = boto3.resource('dynamodb', region_name='us-west-2')
    table = ddbClient.Table(dynamodb_table)
    response = table.scan()
    #print(response)
    #print(event)
    email=event['queryStringParameters']['email']
    #emailHash="68fe0883d6465aa4d0d1f690d25af15619702f0d"
    #Convert to lowercase 
    email=email.lower()
    
    print(email)

    try:
        emailList = []
        for i in response['Items']:
            emailList.append(i['email'])
        #return emailList
        print(emailList)
        #responseGet = table.scan(FilterExpression=Attr('email').eq(email))
        #print(responseGet)
        #items = responseGet['Items']
        #print(items)
        for i in range(len(emailList)):
            emailList[i] = emailList[i].lower()
        print("List items after converting to lowercase")
        print(emailList)
        #if email is not in emailList:
        if email not in emailList:
            print("Email does not exists")
            return {"statusCode": 200,"body": json.dumps("success"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } }
        else:
            print("Email already exists")
            return {"statusCode": 200,"body": json.dumps("exists"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } } 
            
    except ClientError as e:
        print("Here")
        print(e)
        return {"statusCode": 500,"body": json.dumps("error"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } }

  

import json,boto3,sys ,datetime ,time
from botocore.vendored import requests
import hashlib,hmac,random
import pprint
#import psycopg2
import smtplib
import re
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

dynamodb_table= os.environ["dynamodb_table"]
api_gateway_post_url =os.environ["api_gateway_post_url"]
print(dynamodb_table)
print(api_gateway_post_url)

def lambda_handler(event, context):
   
    # TODO implement
    print(event)
    # Email Template

    dynamodb = boto3.resource('dynamodb','us-west-2')
    table = dynamodb.Table(dynamodb_table)
    tableq = dynamodb.Table('cloudaz-questionnaire')
    # Check If customer record exists already
        # Check If customer record exists already
    print(event["Records"][0]['eventName'])
    
    if event["Records"][0]['eventName']=='INSERT':
        emailHash=event["Records"][0]['dynamodb']['NewImage']['emailHash']['S']
        if emailHash:
            print(emailHash)
            responseGet = table.scan(FilterExpression=Attr('emailHash').eq(emailHash))
            items = responseGet['Items']
            print(items)
            if items != [] : 
                for item in items:
                    FirstName =item['firstName']
                    LastName=item['lastName']
                    Company=item['company']
                    email=item['email']
            whatApp=event["Records"][0]['dynamodb']['NewImage']['whatApp']['S']
            whatLanguage=event["Records"][0]['dynamodb']['NewImage']['whatLanguage']['S']
            #email=event["Records"][0]['dynamodb']['Keys']['email']['S']
            anythingElse=event["Records"][0]['dynamodb']['NewImage']['anythingElse']['S']
            emailHash=event["Records"][0]['dynamodb']['NewImage']['emailHash']['S']
       
        # fromEmail =  "admin@cloudaz.com"
        # toEmail = email
        # print(toEmail)
        #toEmail = "gamaresh@nextlabs.com"
            if items != [] : 
                print(FirstName) 
                notifyApprovalTeam(emailHash,FirstName,LastName,Company,email,whatApp,whatLanguage,anythingElse)
                print("email has been sent for approval ")
               
        # except smtplib.SMTPException as e:
        #     print(str(e))
            #print("sss")

#lambda_handler(event,"-")
def notifyApprovalTeam(emailHash,firstName,lastName,company,email,whatApp,whatLanguage,anythingElse):
    fromEmail =  "admin@cloudaz.com"
    #toEmail = "kavashgar@gmail.com"
    #toEmail = "cloudaz-approvers@nextlabs.com"
    toEmail = "gamaresh@nextlabs.com"
    #toEmail = "Kavashgar.Manimarpan@nextlabs.com"
    
    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "CloudAz - : New Registration - Requesting Approval"
    msg['From'] = fromEmail
    msg['To'] = toEmail

    html = """
          <table>
        """
    html=html+'<tr><td colspan="2" ><strong>Registration Details</strong></td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">First Name </td>  <td>'+firstName+'</td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">Last Name </td>  <td>'+lastName+'</td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">Company </td>  <td>'+company+'</td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">Email </td>  <td>'+email+'</td></tr>'
    '<br><br>'
    html=html+'<tr><td colspan="2" ><strong>Questions with Answers</strong></td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">What type of applications? </td>  <td>'+whatApp+'</td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">What programming languages? </td>  <td>'+whatLanguage+'</td></tr>'
    html=html+'<tr><td style="background-color:#FF6101;color:white">Anything else we should know or can help you to make the trial successful? </td>  <td>'+anythingElse+'</td></tr>'
    
    html=html+"""
    </table>
    """
    
    #html=html+'<br><br> <a href="https://c5tnb3yan0.execute-api.us-west-2.amazonaws.com/Staging/approval/?emailHash='+emailHash +'">Approve</a>.'
    html=html+'<br><br> <a href="'+api_gateway_post_url+'"/approval/?emailHash='+emailHash +'">Approve</a>.'
    part1 = MIMEText(html, 'html')
    
    try:
        msg.attach(part1)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("admin@cloudaz.com", "sgjunjhxnqisfmwr")
        text = msg.as_string()
        server.sendmail(fromEmail, toEmail, text)
        server.quit()
        
        return { 
                    "statusCode": 200,
                    "body": json.dumps("success"),
                    "isBase64Encoded": "false",
                    "headers": {
                            "Access-Control-Allow-Origin" : "*", 
                            "Access-Control-Allow-Credentials" : "true"
                     }
                
            }
    except smtplib.SMTPException as e:
        print(str(e))
        return { 
                "statusCode": 500,
                "body": json.dumps("error"),
                "isBase64Encoded": "false",
                "headers": {
                        "Access-Control-Allow-Origin" : "*", 
                        "Access-Control-Allow-Credentials" : "true"
                 }
        
        }
 

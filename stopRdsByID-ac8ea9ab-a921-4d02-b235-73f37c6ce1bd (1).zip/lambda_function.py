
import boto3
def lambda_handler(event, context):
    dbs =  boto3.client('rds').describe_db_instances()
    DBInstanceIdentifiers=['cc86']
    
    for db in dbs['DBInstances']:
        #print(db['DBInstanceIdentifier'])
        if (db['DBInstanceStatus'] == 'available' and db['DBInstanceIdentifier'] in DBInstanceIdentifiers):
                boto3.client('rds').stop_db_instance(DBInstanceIdentifier=db['DBInstanceIdentifier'])
                print("Stopping RDS : "+db['DBInstanceIdentifier'])
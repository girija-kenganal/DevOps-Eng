import json
import boto3

def lambda_handler(event, context):
    
    # get autoscaling client object
    asg = boto3.client('autoscaling', region_name='us-west-2')
    ECS_CLUSTER_NAME='QA-CLOUDAZ-NET'
    
    # scaled down ASG 
    asg_scaledown = asg.update_auto_scaling_group(
          AutoScalingGroupName = 'CC-QA-CLOUDAZ-NET-ASG',
          LaunchConfigurationName = 'QA-CLOUDAZ-NET-LC',
          MaxSize=3,
          MinSize=0,
          DesiredCapacity=0,
          DefaultCooldown=300,
          HealthCheckType='EC2',
          HealthCheckGracePeriod=300,
          AvailabilityZones=[
             'us-west-2a',
             'us-west-2b'
          ],
     )
     
    # get rds client object
    rds = boto3.client('rds', region_name='us-west-2')
    dbs = rds.describe_db_instances()
    
    for db in dbs['DBInstances']:
        print(db['DBInstanceIdentifier'])
        print(db['DBInstanceStatus'])
        
        
        if (db['DBInstanceIdentifier'] == 'cloudaz-dev-qa-upgrade' and db['DBInstanceStatus'] == 'available'):
            stop_rds = rds.stop_db_instance(DBInstanceIdentifier='cloudaz-dev-qa-upgrade')

    # Scale Down all Services to 0
    print("Scaling Down CC container");
    
    ecs = boto3.client('ecs', region_name='us-west-2')
    
    update_service_cc = ecs.update_service(
        cluster=ECS_CLUSTER_NAME,
        service='cc',
        desiredCount=0,
        forceNewDeployment=False,
        taskDefinition='cc-qa:8',
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    
    print("Scaling Down NGINX container");
    
    update_service_pv = ecs.update_service(
        cluster=ECS_CLUSTER_NAME,
        service='nginx',
        desiredCount=0,
        forceNewDeployment=False,
        taskDefinition='nginx-qa:14',
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    
    
    print("Scaling Down ICENET container");
    
    update_service_pv = ecs.update_service(
        cluster=ECS_CLUSTER_NAME,
        service='icenet',
        desiredCount=0,
        forceNewDeployment=False,
        taskDefinition='icenet-qa:3',
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    
    
    print("Scaling Down JPC container");
    
    update_service_jpc = ecs.update_service(
        cluster=ECS_CLUSTER_NAME,
        service='jpc',
        desiredCount=0,
        forceNewDeployment=False,
        taskDefinition='jpc-qa:6',
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    
    
    print("Scaling PV container");
    
    update_service_pv = ecs.update_service(
        cluster=ECS_CLUSTER_NAME,
        service='pv',
        desiredCount=0,
        forceNewDeployment=False,
        taskDefinition='pv-qa:8',
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
            

                
            
import boto3


client = boto3.client('logs')


def lambda_handler(event, context):
   
    #= = = = = = = = = = = = ACT on event Trigger =========
    dd = dict(event['detail'])
    aDict = dict(dd['requestParameters'])
    logGroupName = aDict['logGroupName']

    if "lambda" in logGroupName:
        lambdaLg = client.put_retention_policy(
            logGroupName=logGroupName,
            retentionInDays=14
        )
        # print(lambdaLg)

    else:
        otherLg = client.put_retention_policy(
            logGroupName=logGroupName,
            retentionInDays=90
        )
        
    return 'Processed'



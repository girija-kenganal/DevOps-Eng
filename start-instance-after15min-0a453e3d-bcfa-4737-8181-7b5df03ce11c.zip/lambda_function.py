import boto3
from datetime import datetime
from pytz import timezone
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
        
   
    awsAccounts=['579292207088']
    
    for accountNumber in awsAccounts:
        try:
      
            ec2_client = boto3.client('ec2')
              
            
            
            #regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            regions = ['us-east-1']
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2', region_name=region)
                
                StoppedInstances=['i-01eddfcb3da4efc26','i-003a6a635e53f1e25']
                #instances = clientEC2.instances.filter(InstanceIds=StoppedInstances)
            
                #snsClient=boto3.client('sns')
                #print('I am here')
                #instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['stopped']}])
                #print(instances)
                print(StoppedInstances)
                instanceList = []
                
                for instanceId in StoppedInstances:
                    
                    instance = clientEC2.Instance(instanceId)
                    instanceList.append(instance.id)
                    instance_tags = instance.tags
                    tagDict = dict()
                
                    
                
                    if instance_tags:
                
                        for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                
                        try:
                            # dir(instance)
                            if 'sgdc' in tagDict.values():
                                tzone = timezone('Asia/Singapore')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currTimeM = int(sa_time.strftime('%M'))
                                print(currTime)
                                print(currTimeM)
                                HM = str(currTime) + ":" + "{0:02d}".format(currTimeM)
                                print(HM)
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                #print(tagDict.get('Day'))
                                DayList = tagDict.get('Day')
                                print(DayList)
                                DayFound = str(DayList).find(str(Weekday))
                                print(DayFound)
                                print("TTL Start Time %s %s" % (tagDict.get('TTL Start Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                print(tagDict.get('Project Start Date'))
                                print(tagDict.get('TTL Start Time'))
                                
                                if tagDict.get('Project Start Date') and tagDict.get('Project Start Date') != 'none' and datetime.strptime(tagDict.get('Project Start Date'), '%Y-%m-%d').date() <= currDate:
                                    # Check for the day of the week
                                    print("Cond-1")
                                    if DayFound != -1:
                                        if tagDict.get('TTL Start Time') and tagDict.get('TTL Start Time') != 'none' and tagDict.get('TTL Start Time') == HM:
                                            print("cond-3")
                                            clientEC2.instances.filter(InstanceIds=[instance.id]).start()
                                            print("Starting EC2 instance -  %s" % str(instance.id))
                                            msgString=msgString+"Starting EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                    
                            if 'smdc' in tagDict.values():
                                tzone = timezone('America/Los_Angeles')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currTimeM = int(sa_time.strftime('%M'))
                                print(currTime)
                                print(currTimeM)
                                HM = str(currTime) + ":" + str(currTimeM)
                                print(HM)
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                DayList = tagDict.get('Day')
                                DayFound = str(DayList).find(str(Weekday))
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                print(DayList)
                                print(DayFound)
                                
                                print("TTL Start Time %s %s" % (tagDict.get('TTL Start Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                
                                if tagDict.get('Project Start Date') and tagDict.get('Project Start Date') != 'none' and datetime.strptime(tagDict.get('Project Start Date'), '%Y-%m-%d').date() <= currDate:
                                    # Check for the day of the week
                                    if DayFound != -1:
                                        if tagDict.get('TTL Start Time') and tagDict.get('TTL Start Time') != 'none' and int(tagDict.get('TTL Start Time')) == HM:
                                            clientEC2.instances.filter(InstanceIds=[instance.id]).start()
                                            print("Starting EC2 instance -  %s" % str(instance.id))
                                            msgString=msgString+"Starting EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
            
                            if 'cdc' in tagDict.values():
                                tzone = timezone('Asia/Singapore')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currTimeM = int(sa_time.strftime('%M'))
                                print(currTime)
                                print(currTimeM)
                                HM = str(currTime) + ":" + str(currTimeM)
                                print(HM)
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                DayList = tagDict.get('Day')
                                DayFound = str(DayList).find(str(Weekday))
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                print(DayList)
                                print(DayFound)
                                
                                print("TTL Start Time %s %s" % (tagDict.get('TTL Start Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                
                                if tagDict.get('Project Start Date') and tagDict.get('Project Start Date') != 'none' and datetime.strptime(tagDict.get('Project Start Date'), '%Y-%m-%d').date() <= currDate:
                                    # Check for the day of the week
                                    if DayFound != -1:    
                                        if tagDict.get('TTL Start Time') and tagDict.get('TTL Start Time') != 'none' and int(tagDict.get('TTL Start Time')) == HM:
                                            clientEC2.instances.filter(InstanceIds=[instance.id]).start()
                                            print("Starting EC2 instance -  %s" % str(instance.id))
                                            msgString=msgString+"Starting EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                    
                                    
                        except ClientError as e:
                            print(e)
                            
            if not msgString=='':
                print(msgString)
                
        except ClientError as e:
            print(e) 
    
    return "success"        